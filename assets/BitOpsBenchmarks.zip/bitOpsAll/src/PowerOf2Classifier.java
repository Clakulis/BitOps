/**
 * Classifies integers by their relationship to powers of 2 using bit tricks.
 *
 * <p>Power-of-2 detection and classification is a core building block in:
 *   - Memory allocator buddy systems
 *   - FFT size validation
 *   - Hash table capacity management
 *   - Bitonic sort (size must be power of 2)
 *
 * <p>This class provides functions with multiple conditional branches that are
 * interesting for concolic testing: positive/negative, zero, INT_MIN, exact
 * powers, near-powers, and arbitrary values all follow different paths.
 *
 * <p>Source inspiration: algorithmic patterns from BitonicSort.java (TheAlgorithms)
 * which requires power-of-2 array sizes, adapted into standalone bit classification.
 */
public final class PowerOf2Classifier {

    private PowerOf2Classifier() {}

    /**
     * Returns true if and only if {@code n} is a positive power of 2.
     *
     * <p>Classic bit trick: a power of 2 has exactly one bit set, so {@code n & (n-1) == 0}.
     * Edge cases: 0 is not a power of 2; negative numbers are not powers of 2.
     *
     * @param n the value to test
     * @return true if n is a positive power of 2
     */
    public static boolean isPowerOf2(int n) {
        if (n <= 0) {
            return false;
        }
        return (n & (n - 1)) == 0;
    }

    /**
     * Returns the smallest power of 2 that is ≥ {@code n} (ceiling power of 2).
     *
     * <p>Algorithm: fill all bits below the highest set bit using OR-shifts,
     * then add 1. Special cases handled with branches:
     * <ul>
     *   <li>n ≤ 0 → return 1 (smallest positive power of 2)
     *   <li>n is already a power of 2 → return n
     *   <li>n > 2^30 → result overflows int → return -1 as error sentinel
     * </ul>
     *
     * @param n the input value
     * @return ceiling power of 2 ≥ n, or -1 on overflow
     */
    public static int nextPowerOf2(int n) {
        if (n <= 0) {
            return 1;
        }

        if (n > (1 << 30)) {
            return -1;    // overflow: 2^31 doesn't fit in signed int
        }

        if ((n & (n - 1)) == 0) {
            return n;     // already a power of 2
        }

        // Fill bits below highest set bit, then add 1
        n--;
        n |= (n >>> 1);
        n |= (n >>> 2);
        n |= (n >>> 4);
        n |= (n >>> 8);
        n |= (n >>> 16);
        n++;

        return n;
    }

    /**
     * Returns the largest power of 2 that is ≤ {@code n} (floor power of 2).
     *
     * <p>Algorithm: fill all bits below the highest set bit via OR-shifts, then
     * clear the lower half by right-shift and subtraction.
     *
     * @param n the input value
     * @return floor power of 2 ≤ n, or 0 if n ≤ 0
     */
    public static int prevPowerOf2(int n) {
        if (n <= 0) {
            return 0;
        }

        if ((n & (n - 1)) == 0) {
            return n;     // already a power of 2
        }

        // Fill all bits below the highest → yields (2^k - 1) where 2^k > n
        n |= (n >>> 1);
        n |= (n >>> 2);
        n |= (n >>> 4);
        n |= (n >>> 8);
        n |= (n >>> 16);

        // Remove lower half to get 2^(k-1)
        return n - (n >>> 1);
    }

    /**
     * Returns the exponent {@code k} such that {@code 2^k == n}, or -1 if n is not a power of 2.
     *
     * <p>Bit trick: count trailing zeros (equivalent to log2 for powers of 2).
     * This is computed manually via bit operations without library calls.
     *
     * @param n the input value
     * @return k ≥ 0 such that 2^k == n, or -1 if n is not a power of 2
     */
    public static int log2IfPowerOf2(int n) {
        if (!isPowerOf2(n)) {
            return -1;
        }

        // Count trailing zeros manually using bit operations
        int count = 0;
        int v = n;

        // Each OR-check with a bitmask halves the search space (binary-search for trailing zero)
        if ((v & 0x0000FFFF) == 0) { count |= 16; v >>>= 16; }
        if ((v & 0x00FF00FF) == 0) { count |=  8; v >>>=  8; }  // adjusted mask post-shift
        if ((v & 0x0F0F0F0F) == 0) { count |=  4; v >>>=  4; }
        if ((v & 0x33333333) == 0) { count |=  2; v >>>=  2; }
        if ((v & 0x55555555) == 0) { count |=  1; }

        return count;
    }

    /**
     * Classifies {@code n} into one of several power-of-2 relationship categories.
     *
     * <p>Returns a category code:
     * <ul>
     *   <li>0 – n ≤ 0 (invalid / non-positive)
     *   <li>1 – n is an exact power of 2
     *   <li>2 – n is one less than a power of 2   (e.g. 3, 7, 15, 31, ...)
     *   <li>3 – n is one more than a power of 2   (e.g. 3, 5, 9, 17, ...)  [overlap with 2 for n=3]
     *   <li>4 – n is between two consecutive powers of 2 (general case)
     * </ul>
     *
     * <p>Note: n=3 satisfies both "one less than 4" and "one more than 2", returns category 2 first.
     *
     * @param n the input integer
     * @return category code in [0, 4]
     */
    public static int classify(int n) {
        if (n <= 0) {
            return 0;
        }

        // Check exact power of 2
        if ((n & (n - 1)) == 0) {
            return 1;
        }

        // Check one-less-than power of 2: (n+1) is a power of 2
        // i.e., (n+1) & n == 0. Guard: n == 0x7FFFFFFF causes n+1 to overflow (sign flip).
        if (n != 0x7FFFFFFF && ((n + 1) & n) == 0) {
            return 2;
        }

        // Check one-more-than power of 2: (n-1) is a power of 2
        if (((n - 1) & (n - 2)) == 0 && (n - 1) > 0) {
            return 3;
        }

        // General case: between two powers of 2
        return 4;
    }
}
