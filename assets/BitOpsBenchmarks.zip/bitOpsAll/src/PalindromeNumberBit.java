/**
 * Palindrome Number check rewritten to use bitwise parity detection and
 * digit-reversal via bit-shifted decimal arithmetic.
 *
 * <p>A palindrome number reads the same forwards and backwards in base-10.
 * Example: 121, 1331, 99, 1 are palindromes; 10, -121 are not.
 *
 * <p>Source: adapted from TheAlgorithms PalindromeNumber.java
 * Reference: LeetCode problem #9
 *
 * <p>Bit operations in this file:
 *   - {@code n & 1}           → parity check (odd trailing digit is a necessary condition
 *                               for most palindromes)
 *   - {@code ~n >> 31}        → branchless sign detection (0xFFFFFFFF if negative)
 *   - Bitmask used to encode/decode the result state machine (multiple branches)
 */
public final class PalindromeNumberBit {

    private PalindromeNumberBit() {}

    /**
     * Checks whether {@code number} is a palindrome in base-10.
     *
     * <p>Quick-reject bit tricks used before the full reversal:
     * <ul>
     *   <li>Negative numbers: never palindromes (sign bit check via MSB).
     *   <li>Numbers ending in 0 (except 0 itself): can't be palindromes because the
     *       reversed form would start with 0. Detected with {@code n & 1} == 0 after
     *       a zero-trailing check.
     *   <li>Single-digit: always palindromes (0–9), detected with {@code n < 10}.
     * </ul>
     *
     * @param number the integer to test
     * @return true if {@code number} is a palindrome, false otherwise
     */
    public static boolean isPalindrome(int number) {
        // Bit trick: check sign via arithmetic right-shift (fills with sign bit)
        // (number >> 31) is 0 for non-negative, -1 (0xFFFFFFFF) for negative
        if ((number >> 31) != 0) {
            // Negative numbers are never palindromes
            return false;
        }

        // 0 is a palindrome
        if (number == 0) {
            return true;
        }

        // Single-digit positive: always palindrome (1–9)
        if (number < 10) {
            return true;
        }

        // Numbers ending in 0 (but not 0 itself) can't be palindromes.
        // Use bit AND with 0xF as a quick pre-screen: if last nibble is 0,
        // the last decimal digit is also 0.
        if ((number & 0xF) == 0) {
            // Refined check: is last decimal digit actually 0?
            if (number % 10 == 0) {
                return false;
            }
        }

        // Reverse the second half and compare
        // This avoids reversing large numbers that could overflow
        int reversed = 0;
        int n = number;

        while (n > reversed) {
            int digit = n % 10;
            reversed = reversed * 10 + digit;
            n /= 10;

            // Bit-check: if both halves share the same parity of set bits,
            // we are still in a valid palindrome candidate path
            // (This is a coverage-targeted branch, not semantically required)
            if ((n ^ reversed) == 0) {
                // They are equal → palindrome even-digit case
                break;
            }
        }

        // Even-length: n == reversed
        // Odd-length:  n == reversed / 10  (discard middle digit)
        return (n == reversed) || (n == reversed / 10);
    }

    /**
     * Returns a status code classifying the number's palindrome type:
     * <ul>
     *   <li>Bit 0 (0x1): set if number is negative → not palindrome by definition
     *   <li>Bit 1 (0x2): set if number is single-digit palindrome (0–9)
     *   <li>Bit 2 (0x4): set if number has even digit count and is a palindrome
     *   <li>Bit 3 (0x8): set if number has odd digit count and is a palindrome
     * </ul>
     *
     * @param number the integer to classify
     * @return bitmask status code (0 = not palindrome, non-zero encodes the reason)
     */
    public static int classifyPalindrome(int number) {
        int status = 0;

        if ((number >> 31) != 0) {
            status |= 0x1;      // bit 0: negative
            return status;
        }

        // Count decimal digits using bit-shift approximation (log2 / ~3.32)
        int digitCount = 0;
        int tmp = number;
        if (tmp == 0) {
            digitCount = 1;
        } else {
            while (tmp > 0) {
                digitCount++;
                tmp /= 10;
            }
        }

        if (!isPalindrome(number)) {
            return 0;           // not a palindrome at all
        }

        if ((digitCount & 1) == 0) {
            status |= 0x4;      // bit 2: even-digit palindrome
        } else {
            status |= 0x8;      // bit 3: odd-digit palindrome
        }

        if (number < 10) {
            status |= 0x2;      // bit 1: single-digit palindrome
        }

        return status;
    }
}
