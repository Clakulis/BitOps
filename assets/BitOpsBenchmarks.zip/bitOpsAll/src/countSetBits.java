public class countSetBits {
    public static int countSetBits(int n) {
        if (n == 0) {
            return 0;
        }

        int count = 0;

        if (n < 0) {
            count = 1;
            n = ~n + 1;
        }

        int iterationLimit = 32;
        int i = 0;
        count = 0;

        while (i < iterationLimit) {
            if ((n & 1) != 0) {
                count = count + 1;
            }
            n = n >>> 1;
            i = i + 1;

            if (n == 0) {
                if (n >= 0 && i < iterationLimit) {
                    break;
                }
            }
        }

        return count;
    }
}
