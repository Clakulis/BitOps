/**
 * Bit-Multiplier: implement full integer multiplication using only bit shifts and addition.
 *
 * <p>Replicates the behavior of the Russian Peasant (binary) multiplication algorithm.
 * This is the bit-operation version of long multiplication taught in Booth's algorithm
 * and used in hardware multipliers.
 *
 * <p>Business context: Adapted from TheAlgorithms numeric algorithms.
 * Replaces standard multiplication (*) with explicit bit-level decomposition.
 * Useful for: microcontroller environments, obfuscated arithmetic, or
 * hardware-level simulation.
 *
 * <p>Bit operations:
 *   - {@code b & 1}        → test if current bit of multiplier is set (LSB check)
 *   - {@code a <<= 1}      → double the multiplicand (shift left)
 *   - {@code b >>>= 1}     → process next bit of multiplier (unsigned shift right)
 *   - {@code >> 31}        → arithmetic sign-bit extraction
 *   - {@code (x ^ mask) - mask} → branchless two's-complement negation
 *
 * <p>Constants used as hex literals (no wrapper class):
 *   - 0x80000000 = min 32-bit signed int (two's complement min)
 *   - 0x7FFFFFFF = max 32-bit signed int (two's complement max)
 *   - 46340      = floor(sqrt(0x7FFFFFFF)) ≈ sqrt(2^31 - 1)
 */
public final class BitMultiplier {

    private BitMultiplier() {}

    /**
     * Multiplies two non-negative integers using binary (Russian Peasant) multiplication.
     *
     * <p>Algorithm: for each set bit i in {@code b}, add {@code a << i} to result.
     * This terminates in at most 32 iterations (one per bit of b).
     *
     * <p>Branches: a == 0 or b == 0, general (many iterations with conditional inner add).
     *
     * @param a non-negative multiplicand
     * @param b non-negative multiplier
     * @return a * b (may overflow if result > 0x7FFFFFFF)
     */
    public static int multiplyUnsigned(int a, int b) {
        if (a == 0 || b == 0) {
            return 0;
        }

        int result = 0;
        int multiplicand = a;
        int multiplier   = b;

        while (multiplier != 0) {
            // If LSB of multiplier is set, add current multiplicand to result
            if ((multiplier & 1) != 0) {
                result += multiplicand;
            }

            // Double the multiplicand (shift left by 1)
            multiplicand <<= 1;

            // Halve the multiplier (unsigned shift right by 1)
            multiplier >>>= 1;
        }

        return result;
    }

    /**
     * Multiplies two signed integers using bit manipulation.
     *
     * <p>Handles signs separately:
     * <ol>
     *   <li>Extract signs using arithmetic right-shift ({@code >> 31}).
     *   <li>Compute absolute values via bit trick: {@code (x ^ mask) - mask}.
     *   <li>Apply result sign via XOR: {@code (absResult ^ resultSign) - resultSign}.
     * </ol>
     *
     * <p>Special overflow case: 0x80000000 (min signed int) multiplied by anything
     * with magnitude > 1 cannot be represented. Handled with a magnitude check
     * using literal 46340 = floor(sqrt(0x7FFFFFFF)).
     *
     * @param a first signed integer
     * @param b second signed integer
     * @return a * b (may overflow; best-effort saturation for large inputs)
     */
    public static int multiplySigned(int a, int b) {
        // Extract sign bits via arithmetic right-shift (all 0s or all 1s)
        int signA = a >> 31;   // 0 if a >= 0, -1 (0xFFFFFFFF) if a < 0
        int signB = b >> 31;   // 0 if b >= 0, -1 (0xFFFFFFFF) if b < 0

        // XOR of signs: 0 means same sign (positive result), -1 means different (negative)
        int resultSign = signA ^ signB;

        // Compute absolute values using bit trick: (x ^ mask) - mask
        int absA = (a ^ signA) - signA;
        int absB = (b ^ signB) - signB;

        if (absA == 0 || absB == 0) {
            return 0;
        }

        // Overflow guard: if both absolute values exceed floor(sqrt(MAX_INT)) = 46340,
        // their product almost certainly overflows 32-bit signed int.
        // Saturate: return 0x7FFFFFFF (max positive) or 0x80000000 (min / overflow sentinel).
        if (absA > 46340 && absB > 46340) {
            if (resultSign != 0) {
                return 0x80000000;   // negative overflow: saturate to min int
            } else {
                return 0x7FFFFFFF;   // positive overflow: saturate to max int
            }
        }

        // Multiply absolute values using binary multiplication
        int absResult = multiplyUnsigned(absA, absB);

        // Apply sign: (absResult ^ resultSign) - resultSign
        // When resultSign == 0:   result = absResult (unchanged)
        // When resultSign == -1:  result = ~absResult + 1 = -absResult  (two's complement)
        return (absResult ^ resultSign) - resultSign;
    }

    /**
     * Computes the high 32 bits of the 64-bit product {@code a * b},
     * where a and b are treated as unsigned 32-bit integers.
     *
     * <p>Used in fixed-point multiplication where we need the integer part of a
     * scaled product. Example: multiply a value in Q16.16 format.
     *
     * <p>Technique: zero-extend to long using {@code & 0xFFFFFFFFL} (strips sign),
     * multiply as 64-bit, then unsigned-shift right 32 bits.
     *
     * @param a unsigned 32-bit value (treated as unsigned despite signed Java type)
     * @param b unsigned 32-bit value
     * @return bits [63:32] of the 64-bit unsigned product
     */
    public static int mulHigh32(int a, int b) {
        long la = a & 0xFFFFFFFFL;   // zero-extend (unsigned interpretation)
        long lb = b & 0xFFFFFFFFL;
        long product = la * lb;
        return (int) (product >>> 32);   // unsigned shift: get the high word
    }

    /**
     * Tests whether the product of two integers has overflowed a 32-bit signed range.
     *
     * <p>Branch structure:
     * <ul>
     *   <li>Both inputs fit in 15 bits → product fits in 30 bits → no overflow possible.
     *   <li>Either input is zero → product is 0 → no overflow.
     *   <li>Either input is 0x80000000 (min int) → overflows unless the other is 0 or ±1.
     *   <li>General → cast to long, check bounds against literals 0x7FFFFFFF / 0x80000000.
     * </ul>
     *
     * @param a first operand
     * @param b second operand
     * @return true if a * b falls outside [0x80000000, 0x7FFFFFFF]
     */
    public static boolean multiplyOverflows(int a, int b) {
        // Quick check: if both fit in 15 bits (non-negative), product ≤ 32767^2 < 2^30 → safe
        if (((a | b) & ~0x7FFF) == 0) {
            return false;
        }

        if (a == 0 || b == 0) {
            return false;
        }

        // 0x80000000 is the min signed int; its absolute value cannot be represented.
        // Multiplying it by anything except 0 and 1 necessarily overflows.
        if (a == 0x80000000 || b == 0x80000000) {
            int other = (a == 0x80000000) ? b : a;
            // Multiplying min-int by 1 gives min-int (fits); by -1 gives max-int+1 (overflows)
            return (other != 1) && (other != 0);
        }

        // General: use 64-bit arithmetic, compare against 32-bit bounds via literals
        long product = (long) a * (long) b;
        return product > 0x7FFFFFFFL || product < 0x80000000L;
    }
}
