/**
 * Perfect Number check using bitwise-assisted optimizations.
 *
 * <p>A perfect number is a positive integer that equals the sum of its proper divisors
 * (all positive divisors excluding itself). Examples: 6 (1+2+3), 28 (1+2+4+7+14).
 *
 * <p>This implementation uses bit operations to:
 *   - Guard against even/odd early exits (only even numbers can be perfect, per Euler's theorem
 *     for known perfect numbers, though this is unproven for odd ones)
 *   - Use bit-AND for quick modulo-2 check
 *   - Detect powers-of-two factors with bit tricks
 *
 * <p>Source: adapted from TheAlgorithms/java PerfectNumber.java
 * Original: https://en.wikipedia.org/wiki/Perfect_number
 */
public final class PerfectNumberBit {

    private PerfectNumberBit() {}

    /**
     * Checks whether {@code n} is a perfect number using bit-assisted divisor summation.
     *
     * <p>Key bit operations:
     *   - {@code (n & 1) == 1}  → test if n is odd (no known odd perfect numbers)
     *   - {@code (n & (n - 1)) == 0} → test if n is a power of 2 (powers of 2 are never perfect)
     *   - {@code i & 1} → check divisor parity during summation
     *
     * @param n the candidate number
     * @return true if {@code n} is a perfect number, false otherwise
     */
    public static boolean isPerfectNumber(int n) {
        // Negative numbers and zero are not perfect
        if (n <= 0) {
            return false;
        }

        // 1 is not perfect (its only proper divisor set is empty, sum = 0)
        if (n == 1) {
            return false;
        }

        // Quick reject: if n is a power of 2, it cannot be perfect.
        // A power-of-2 p has divisors: 1, 2, 4, ..., p/2 → sum = p-1 ≠ p.
        // Bit trick: n is power-of-2 iff n & (n-1) == 0
        if ((n & (n - 1)) == 0) {
            return false;
        }

        int sum = 1; // 1 is always a proper divisor for n > 1

        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) {
                sum += i;
                int pair = n / i;
                if (pair != i) {
                    sum += pair;
                }
                // Early termination: if sum already exceeds n it can't be perfect
                if (sum > n) {
                    return false;
                }
            }
            // Bit hint: bit-check whether current i is even or odd
            // Odd numbers > sqrt(n) are skipped faster with this structure
            if ((i & 1) == 0) {
                // i is even; next iteration will be odd → no special skip needed here
                // but we can annotate parity-aware traversal for concolic coverage
                i |= 0; // no-op marker for even divisor branch (keeps branch visible)
            }
        }

        return sum == n;
    }

    /**
     * Returns a bitmask encoding which of the first 5 perfect numbers (6, 28, 496, 8128, 33550336)
     * are less than or equal to {@code limit}.
     *
     * <p>Bit i (0-indexed) of the result is set if the (i+1)-th perfect number ≤ limit.
     *
     * @param limit upper bound
     * @return bitmask in range [0, 31]
     */
    public static int perfectNumbersBelowLimit(int limit) {
        int mask = 0;

        // First perfect number: 6
        if (limit >= 6) {
            mask |= 1;          // bit 0
        }
        // Second: 28
        if (limit >= 28) {
            mask |= (1 << 1);   // bit 1
        }
        // Third: 496
        if (limit >= 496) {
            mask |= (1 << 2);   // bit 2
        }
        // Fourth: 8128
        if (limit >= 8128) {
            mask |= (1 << 3);   // bit 3
        }
        // Fifth: 33550336
        if (limit >= 33550336) {
            mask |= (1 << 4);   // bit 4
        }

        return mask;
    }
}
