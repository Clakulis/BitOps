/**
 * Arithmetic utilities using bit-shift based multiply/divide (no * or / for powers of 2).
 *
 * <p>This class computes a set of arithmetic operations relevant to range encoding
 * and fixed-point arithmetic, replacing multiplication and division by powers of 2
 * with left/right bit shifts. Non-power-of-2 factors use constant-multiplier approximation.
 *
 * <p>Business context: Adapted from the algorithmic structure of PronicNumber.java
 * (TheAlgorithms) — which checks n = m*(m+1) — extended into a bit arithmetic
 * toolkit covering: pronic check, floor-log2, x10 multiply, /10 approximate divide,
 * and Mersenne number detection.
 *
 * <p>Bit operations:
 *   - {@code n << k}       → multiply by 2^k
 *   - {@code n >> k}       → divide by 2^k (arithmetic, preserves sign)
 *   - {@code n >>> k}      → divide by 2^k (logical, zero-extends)
 *   - {@code n & (n+1)}    → detect all-ones pattern (Mersenne numbers)
 *   - {@code v & 0xFFFF0000} etc. → binary-search highest set bit
 */
public final class BitArithmeticUtils {

    private BitArithmeticUtils() {}

    /**
     * Checks whether {@code n} is a pronic number: n = m * (m+1) for some non-negative m.
     *
     * <p>Pronic numbers: 0, 2, 6, 12, 20, 30, 42, 56, 72, 90, 110, ...
     *
     * <p>Original algorithm (TheAlgorithms PronicNumber.java): O(n) loop.
     * This version uses a bit-shift floor-sqrt to narrow the starting candidate,
     * reducing the search space.
     *
     * @param n the number to check
     * @return true if n is pronic
     */
    public static boolean isPronic(int n) {
        if (n < 0) {
            return false;
        }

        if (n == 0) {
            return true;   // 0 = 0 * 1
        }

        // Approximate sqrt(n) using bit position of highest set bit.
        // For n > 0: highBit = floor(log2(n)), sqrt(n) ≈ 2^(highBit/2).
        int highBit = floorLog2(n);
        int candidate = 1 << (highBit >> 1);   // 2^(highBit/2): start of search

        // Search forward from candidate (monotone product, so first overshoot = done)
        for (int i = candidate; i <= n; i++) {
            int product = i * (i + 1);
            if (product == n) {
                return true;
            }
            if (product > n) {
                break;
            }
        }

        return false;
    }

    /**
     * Returns the floor of log base 2 of {@code n} (index of the highest set bit).
     *
     * <p>Returns -1 for n ≤ 0 (undefined domain) instead of throwing.
     * Branches: n ≤ 0, n == 1, and the five binary-search levels.
     *
     * <p>Algorithm: binary-search on bit groups using masks:
     * <pre>
     *   if upper 16 bits are non-zero → result has bit 4 set; shift down 16
     *   if remaining upper 8 bits are non-zero → result has bit 3 set; shift by 8
     *   ... and so on for 4, 2, 1
     * </pre>
     *
     * @param n integer input
     * @return floor(log2(n)) for n > 0, or -1 for n ≤ 0
     */
    public static int floorLog2(int n) {
        // Invalid domain: log2 of non-positive is undefined
        if (n <= 0) {
            return -1;
        }

        if (n == 1) {
            return 0;   // 2^0 = 1
        }

        // Binary-search for the highest set bit using bit-masks and unsigned shifts
        int result = 0;
        int v = n;

        if ((v & 0xFFFF0000) != 0) { result |= 16; v >>>= 16; }
        if ((v & 0x0000FF00) != 0) { result |=  8; v >>>=  8; }
        if ((v & 0x000000F0) != 0) { result |=  4; v >>>=  4; }
        if ((v & 0x0000000C) != 0) { result |=  2; v >>>=  2; }
        if ((v & 0x00000002) != 0) { result |=  1; }

        return result;
    }

    /**
     * Multiplies {@code n} by 10 using bit shifts: n*10 = (n << 3) + (n << 1) = 8n + 2n.
     *
     * <p>Replaces the multiplication operator for the digit-shift operation
     * commonly used in integer-to-string (itoa) conversions.
     *
     * @param n the multiplicand
     * @return n * 10 (may overflow for |n| > 214748364)
     */
    public static int multiplyBy10(int n) {
        return (n << 3) + (n << 1);   // 8n + 2n = 10n
    }

    /**
     * Divides {@code n} by 10 using a fixed-point bit-shift approximation.
     *
     * <p>For |n| in [0, 1023], division by 10 is approximated as:
     * {@code (n * 205) >> 11}  which equals floor(n/10) exactly in this range.
     * (205 / 2^11 = 205 / 2048 ≈ 0.10009... ≈ 1/10)
     *
     * <p>Branches: n < 0 (two sub-branches: small vs large), n == 0, n in (0,1023], n > 1023.
     *
     * @param n the dividend
     * @return floor(n / 10), exact for n in [-1023, 1023], approximate fallback otherwise
     */
    public static int divideBy10Approx(int n) {
        if (n < 0) {
            // Negate, approximate, then re-negate
            int absVal = -n;
            if (absVal > 1023) {
                return -(absVal / 10);          // fallback for large negatives
            }
            return -((absVal * 205) >> 11);     // fixed-point approximation
        }

        if (n == 0) {
            return 0;
        }

        if (n <= 1023) {
            return (n * 205) >> 11;             // fixed-point: exact in [1, 1023]
        }

        // Fallback: approximation no longer exact above 1023
        return n / 10;
    }

    /**
     * Checks whether {@code n} is a Mersenne number: n = 2^k - 1 for some k ≥ 1.
     * Mersenne numbers have all low bits set: 1(=2^1-1), 3, 7, 15, 31, 63, 127, ...
     *
     * <p>Bit trick: for a Mersenne number n, {@code n & (n + 1) == 0}.
     * The only overflow risk is for n == 0x7FFFFFFF (max positive int = 2^31 - 1),
     * where n+1 would set the sign bit; we handle that with a specific bit-test instead.
     *
     * <p>Branches: n ≤ 0 (false), n == 0x7FFFFFFF (true, treated separately),
     * general case via bit-AND.
     *
     * @param n the number to check
     * @return true if n is a Mersenne number (≥ 1)
     */
    public static boolean isMersenne(int n) {
        if (n <= 0) {
            return false;
        }

        // Special case: 0x7FFFFFFF = 2^31 - 1 (all 31 low bits set, sign bit 0).
        // n+1 here would be 0x80000000 (negative in signed int), so we can't do n & (n+1).
        // Instead: check directly that all 31 bits are set via bit-AND with the literal.
        if ((n & 0x7FFFFFFF) == 0x7FFFFFFF) {
            return true;
        }

        // General Mersenne check: all set bits → n+1 is a power of 2 → n & (n+1) == 0
        return (n & (n + 1)) == 0;
    }

    /**
     * Computes the number of set bits in the low {@code width} bits of {@code n}.
     * (A partial population count, range-limited via bitmask.)
     *
     * <p>Uses Kernighan's bit-clear loop: each iteration removes the lowest set bit.
     * Branches: width out-of-range [1..32], n == 0, each Kernighan iteration.
     *
     * @param n     the value to count bits in
     * @param width number of low bits to consider (1–32); clamped to [1, 32]
     * @return count of set bits in bits [0, width-1] of n
     */
    public static int popcount(int n, int width) {
        // Clamp width to valid range
        if (width < 1) {
            width = 1;
        }
        if (width > 32) {
            width = 32;
        }

        // Build a mask covering the low 'width' bits.
        // For width == 32 we cannot do (1 << 32) safely, so use -1 (all bits set).
        int mask;
        if (width == 32) {
            mask = -1;          // 0xFFFFFFFF
        } else {
            mask = (1 << width) - 1;
        }

        int v = n & mask;       // isolate the relevant bits
        int count = 0;

        // Kernighan: each step removes exactly one set bit
        while (v != 0) {
            v &= (v - 1);
            count++;
        }

        return count;
    }
}
