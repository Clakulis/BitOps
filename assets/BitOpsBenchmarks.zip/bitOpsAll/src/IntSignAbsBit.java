/**
 * Integer Sign and Absolute Value using pure bit operations (no branching library calls).
 *
 * <p>This class demonstrates how arithmetic with signed 32-bit integers can be
 * implemented entirely via bitwise operators, replacing conditional branches with
 * bitmask selections. It is intentionally designed with multiple branch paths
 * covering: positive, negative, zero, INT_MIN overflow, and mixed operands.
 *
 * <p>Techniques:
 *   - Arithmetic right-shift to extract/propagate sign bit
 *   - Two's complement negation: {@code ~x + 1}
 *   - Branchless selection: {@code (mask & a) | (~mask & b)}
 *   - Overflow detection: INT_MIN (0x80000000) is its own negation
 *
 * <p>Business context: safe integer sign/abs utilities often needed in
 * numeric algorithms that require branchless sign/magnitude extraction.
 */
public final class IntSignAbsBit {

    private IntSignAbsBit() {}

    /**
     * Returns the sign of {@code x}:
     * <ul>
     *   <li>+1 if x > 0
     *   <li>-1 if x < 0
     *   <li> 0 if x == 0
     * </ul>
     *
     * <p>Bit implementation:
     * <pre>
     *   signMask = x >> 31        // 0 if x >= 0, 0xFFFFFFFF if x < 0
     *   neg      = x >> 31        // -1 or 0
     *   pos      = (-x) >> 31     // -1 if x < 0 (i.e. -x > 0), 0 otherwise
     *   sign     = neg | ((-x) >>> 31)
     * </pre>
     *
     * @param x the input value
     * @return -1, 0, or +1
     */
    public static int sign(int x) {
        // Arithmetic right shift: propagates sign bit across all 32 bits
        int negMask = x >> 31;   // 0x00000000 if x >= 0, 0xFFFFFFFF if x < 0

        if (negMask != 0) {
            // x is strictly negative
            return -1;
        }

        // Unsigned right shift of -x: if x > 0 then -x < 0 → MSB is 1 → shift gives 1
        int posMask = (-x) >>> 31;

        if (posMask != 0) {
            // x is strictly positive
            return 1;
        }

        // x == 0
        return 0;
    }

    /**
     * Returns the absolute value of {@code x} using bit manipulation.
     *
     * <p>For non-0x80000000 values: mask = x >> 31; result = (x ^ mask) - mask
     * This is the standard branchless abs trick.
     * For 0x80000000 (min signed int), the absolute value overflows int → return as-is.
     *
     * @param x the input value
     * @return |x| for all x except 0x80000000, which returns 0x80000000 (overflow sentinel)
     */
    public static int abs(int x) {
        // Detect INT_MIN (0x80000000): it is the only value where x < 0 && -x < 0.
        // We cannot represent its true absolute value in 32-bit signed int → return as-is.
        if (x == 0x80000000) {
            return 0x80000000;   // overflow sentinel: abs(INT_MIN) wraps back to INT_MIN
        }

        // Arithmetic right-shift fills all bits with sign bit
        int mask = x >> 31;  // 0 for non-negative, -1 (0xFFFFFFFF) for negative

        // Branchless abs: XOR with mask flips bits (one's complement) for negative,
        // then subtracting mask (+1 for negative, +0 for positive) completes two's complement
        return (x ^ mask) - mask;
    }

    /**
     * Returns the maximum of two integers using bit operations only (no comparisons returned).
     *
     * <p>Technique: branchless selection via sign-bit masking.
     * <pre>
     *   diff = a - b
     *   mask = diff >> 31   // 0xFFFFFFFF if a < b (diff negative), 0 if a >= b
     *   max  = b + (diff & ~mask)   // selects a-b iff a >= b, else 0
     * </pre>
     *
     * <p>Note: overflow possible if a and b have different signs and large magnitude.
     * For safe use, inputs should be within [-2^30, 2^30].
     *
     * @param a first integer
     * @param b second integer
     * @return the larger of a and b
     */
    public static int max(int a, int b) {
        int diff = a - b;
        int mask = diff >> 31;   // all 0s if a >= b, all 1s if a < b

        // If mask is all 0s: ~mask is all 1s → (diff & ~mask) = diff → result = b + diff = a
        // If mask is all 1s: ~mask is all 0s → (diff & ~mask) = 0   → result = b
        return b + (diff & ~mask);
    }

    /**
     * Returns the minimum of two integers using bit operations.
     *
     * @param a first integer
     * @param b second integer
     * @return the smaller of a and b
     */
    public static int min(int a, int b) {
        int diff = a - b;
        int mask = diff >> 31;   // all 1s if a < b, all 0s if a >= b

        // If mask is all 1s: (diff & mask) = diff → result = b + diff = a  (a < b, return a)
        // If mask is all 0s: (diff & mask) = 0   → result = b              (a >= b, return b)
        return b + (diff & mask);
    }

    /**
     * Determines the "sign class" of a value as a 2-bit code:
     * <ul>
     *   <li>0b00 (0): zero
     *   <li>0b01 (1): positive
     *   <li>0b10 (2): negative (non-overflow)
     *   <li>0b11 (3): INT_MIN (overflow case)
     * </ul>
     *
     * @param x the input value
     * @return 2-bit sign class in [0, 3]
     */
    public static int signClass(int x) {
        // 0x80000000 is INT_MIN: the only negative number whose negation also overflows
        if (x == 0x80000000) {
            return 0b11;        // 3: overflow / INT_MIN special case
        } else if (x == 0) {
            return 0b00;        // 0: zero
        } else if ((x >> 31) == 0) {
            return 0b01;        // 1: positive
        } else {
            return 0b10;        // 2: negative (non-overflow)
        }
    }
}
