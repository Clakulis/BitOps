/**
 * In computer science, the population count (or Hamming weight) of an integer
 * is the number of 1-bits in its binary representation.
 *
 * <p>
 * This method demonstrates how to compute the number of set bits in a 32-bit
 * integer using the unsigned right shift operator (>>>), ensuring correctness
 * for both positive and negative values.
 *
 * <p>
 * The algorithm repeatedly shifts the bits of the input value to the right,
 * checking each least significant bit. The use of >>> (unsigned shift)
 * prevents sign bit propagation for negative numbers, making it suitable
 * for unsigned interpretation.
 *
 * <p> Example:
 * <pre>
 *     Input:  value = -3
 *     Binary: 11111111111111111111111111111101
 *     Output: 31  (since there are 31 bits set to 1)
 * </pre>
 *
 * <p>
 * Related concept: Hamming Weight, Bit Manipulation, Unsigned Arithmetic
 *
 * @see <a href="https://en.wikipedia.org/wiki/Hamming_weight">Hamming Weight</a>
 */
public final class BitCountUsingShift {
    private BitCountUsingShift() {}

    /**
     * Counts the number of 1 bits (set bits) in a 32-bit integer using >>>.
     *
     * @param value integer to count bits from
     * @return number of 1 bits in the binary representation
     */
    public static int countBits(int value) {
        int count = 0;

        // Repeat until all bits have been shifted out
        while (value != 0) {
            // Check if the least significant bit is set
            count += (value & 1);

            // Unsigned shift right by 1 to avoid sign extension
            value >>>= 1;
        }

        return count;
    }

    /**
     * Checks whether a number has an odd number of bits set.
     * Useful in parity calculations or checksums.
     *
     * @param value integer value
     * @return true if number of set bits is odd, false otherwise
     */
    public static boolean hasOddParity(int value) {
        return (countBits(value) & 1) == 1;
    }
}