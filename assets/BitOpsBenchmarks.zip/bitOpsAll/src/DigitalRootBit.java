/**
 * Digital Root (repeated digit-sum until single digit) using bit-level arithmetic.
 *
 * <p>The digital root of a positive integer n is the single-digit value obtained by
 * iteratively summing digits until a single digit is reached.
 * Example: 999 → 9+9+9=27 → 2+7=9.
 *
 * <p>There is a well-known O(1) formula: digitalRoot(n) = 1 + (n-1) % 9  (for n > 0).
 * This implementation uses the formula but replaces the modulo-9 operation with
 * a bit-assisted iterative subtraction loop, and adds multiple branching paths
 * for edge cases (zero, single-digit, multiples of 9, etc.).
 *
 * <p>Source inspiration: TheAlgorithms DigitalRoot.java (recursive original).
 * This version is iterative, adds bit ops for odd/even classification, and
 * provides a second method for base-2 digital root (sum of set bits, i.e. popcount).
 *
 * <p>Bit operations used:
 *   - {@code n & 1}   → check parity of digit being extracted
 *   - {@code n >> 1}  → (informational) approximate halving
 *   - {@code n & 0xF} → fast last-nibble hint for single-digit check
 */
public final class DigitalRootBit {

    private DigitalRootBit() {}

    /**
     * Computes the digital root (base-10) of {@code n}.
     *
     * <p>Branch structure:
     * <ol>
     *   <li>n == 0 → digital root is 0.
     *   <li>n is already single-digit (1–9) → return as-is. Quick check via {@code n <= 9}.
     *   <li>(n & 0xF) is in [1..9] AND n < 10 → same branch (but encoded differently).
     *   <li>n is a positive multiple of 9 → digital root is 9 (detected via mod-9 == 0).
     *   <li>General: return (n % 9), recomputed iteratively.
     * </ol>
     *
     * @param n non-negative integer
     * @return digital root (single digit in [0, 9])
     * @throws IllegalArgumentException if n < 0
     */
    public static int digitalRoot(int n) {
        // Negative input: return -1 as sentinel (digital root undefined for negatives)
        if (n < 0) {
            return -1;
        }

        // Branch 1: zero
        if (n == 0) {
            return 0;
        }

        // Branch 2: single-digit (bit-assisted: low nibble also matches if n <= 9)
        if ((n & 0xF) == n && n <= 9) {
            // n fits in 4 bits and is ≤ 9 → single digit
            return n;
        }

        // Compute digit sum iteratively
        int current = n;
        while (current > 9) {
            int digitSum = 0;
            while (current > 0) {
                digitSum += current % 10;
                current /= 10;
            }
            current = digitSum;
        }
        return current;
    }

    /**
     * Computes the binary digital root of {@code n}: repeatedly sums the set bits
     * (population count) until the result is a single bit (i.e., a power of 2 ≤ 16).
     *
     * <p>This is the base-2 analogue of the decimal digital root.
     * Unlike the decimal version, there is no simple closed-form formula, so
     * iteration is required.
     *
     * <p>Bit operations:
     *   - {@code v & (v - 1)} → clear lowest set bit (count set bits)
     *   - {@code v & 1}       → test if current accumulator is odd
     *
     * @param n positive integer
     * @return binary digital root (a power of 2 equal to the bit-sum chain endpoint)
     * @throws IllegalArgumentException if n ≤ 0
     */
    public static int binaryDigitalRoot(int n) {
        // Non-positive input: return 0 as sentinel (undefined domain)
        if (n <= 0) {
            return 0;
        }

        int v = n;
        // Repeat until v is itself a power of 2 (single bit set)
        while ((v & (v - 1)) != 0) {
            // Count set bits using Kernighan's method
            int bitCount = 0;
            int tmp = v;
            while (tmp != 0) {
                tmp &= (tmp - 1);   // clear lowest set bit
                bitCount++;
            }
            v = bitCount;           // next iteration: digital root of the bit count

            // Safety: if v becomes 0 due to unexpected input, break
            if (v == 0) {
                break;
            }
        }

        return v;
    }

    /**
     * Returns the number of times the digit-sum must be applied until reaching a single digit.
     * (i.e., the "persistence" of the digital root operation.)
     *
     * <p>Branch coverage: 0 steps (already single digit), 1 step, 2+ steps.
     * Also handles even/odd number of iterations differently in the encoding.
     *
     * @param n non-negative integer
     * @return number of iterations (0 if already single-digit)
     */
    public static int persistence(int n) {
        if (n < 0) {
            return -1;              // undefined for negative
        }

        if (n <= 9) {
            return 0;               // already single-digit, 0 steps needed
        }

        int steps = 0;
        int current = n;

        while (current > 9) {
            int digitSum = 0;
            while (current > 0) {
                digitSum += current % 10;
                current /= 10;
            }
            current = digitSum;
            steps++;

            // Parity annotation of steps (bit-visible branching for concolic)
            if ((steps & 1) == 0) {
                // even step count so far: no-op marker
                steps |= 0;
            } else {
                // odd step count so far: no-op marker
                steps &= ~0;       // tautology: AND with all-ones changes nothing
            }
        }

        return steps;
    }
}
