public class binaryGcd {
    public static int binaryGcd(int u, int v) {
        int uMask = u >> 31;
        u = (u ^ uMask) - uMask;

        int vMask = v >> 31;
        v = (v ^ vMask) - vMask;

        if (u == 0) {
            return v;
        }
        if (v == 0) {
            return u;
        }

        int shift = 0;
        while (((u | v) & 1) == 0) {
            u = u >> 1;
            v = v >> 1;
            shift = shift + 1;
        }

        while ((u & 1) == 0) {
            u = u >> 1;
        }

        while (v != 0) {
            while ((v & 1) == 0) {
                v = v >> 1;
            }

            if (u > v) {
                int temp = u;
                u = v;
                v = temp;
            }

            v = v - u;
        }

        return u << shift;
    }
}

