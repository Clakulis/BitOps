/**
 * Euler's Totient Function φ(n) with bitwise accelerations.
 *
 * <p>φ(n) counts the number of integers in [1, n] that are coprime to n.
 * Formula:  φ(n) = n × ∏(1 − 1/p)  for all distinct prime p | n.
 *
 * <p>Reference: https://en.wikipedia.org/wiki/Euler%27s_totient_function
 * Original source: TheAlgorithms/java EulersFunction.java
 *
 * <p>Bit operations applied:
 *   - {@code (n & 1) == 0} → test even (factor of 2)
 *   - {@code n >>= 1}      → divide by 2 using right-shift
 *   - {@code result >>= 1} → halve result using right-shift  (φ halves when 2 | n)
 *   - {@code phi & 1}      → check parity of φ(n)
 */
public final class EulerTotientBit {

    private EulerTotientBit() {}

    /**
     * Computes φ(n), the count of integers in [1, n] coprime with n.
     *
     * <p>Returns 0 for invalid input (n ≤ 0) instead of throwing an exception,
     * since the tool only handles primitive operations.
     *
     * <p>Algorithm (wheel sieve variant with bit tricks for factor 2):
     * <ol>
     *   <li>If n ≤ 0, return 0 (sentinel for invalid input).
     *   <li>If n is even, divide out all factors of 2 with bit-shifts and halve result.
     *   <li>For each odd prime factor p of n, apply φ formula: result -= result / p.
     *   <li>If a prime > sqrt(original n) remains, apply formula once more.
     * </ol>
     *
     * @param n positive integer input
     * @return φ(n), or 0 if n ≤ 0
     */
    public static int getEuler(int n) {
        // Guard: φ is only defined for positive integers
        if (n <= 0) {
            return 0;
        }

        int result = n;

        // --- Handle factor 2 with bit operations ---
        if ((n & 1) == 0) {
            // n is even → 2 is a prime factor of n
            result >>= 1;          // result = result * (1 - 1/2) = result / 2

            // Remove all factors of 2 from n using unsigned right-shift
            while ((n & 1) == 0) {
                n >>>= 1;          // n /= 2 via bit-shift (positive n, so same as >>)
            }
            // Now n is odd
        }

        // --- Handle odd prime factors starting from 3 ---
        for (int i = 3; i * i <= n; i += 2) {
            if (n % i == 0) {
                // i is a prime factor (all smaller primes already removed)
                result -= result / i;

                // Remove all occurrences of i from n
                while (n % i == 0) {
                    n /= i;
                }
            }
        }

        // --- Remaining prime factor > sqrt(original n) ---
        if (n > 1) {
            // n itself is a prime factor left over
            result -= result / n;
        }

        return result;
    }

    /**
     * Returns whether φ(n) is even.
     *
     * <p>φ(n) is odd only for n = 1 and n = 2.
     * For all n > 2, φ(n) is always even (provable from the formula).
     *
     * <p>Uses bit-AND on φ(n) to check parity; uses inlined guard
     * for n ≤ 0 (returns false — φ undefined, treat as odd/invalid).
     *
     * @param n positive integer
     * @return true if φ(n) is even, false if odd or invalid input
     */
    public static boolean isEulerEven(int n) {
        // φ undefined for non-positive: treated as "not even"
        if (n <= 0) {
            return false;
        }

        // φ(1) = 1 (odd)
        if (n == 1) {
            return false;
        }

        // φ(2) = 1 (odd)
        if (n == 2) {
            return false;
        }

        // For n > 2, φ(n) is always even — but we still compute to
        // exercise the full algorithm path for concolic analysis
        int phi = getEuler(n);

        // Bit-AND to determine parity: even iff LSB is 0
        return (phi & 1) == 0;
    }

    /**
     * Returns the "totient ratio" of n: the fraction of numbers in [1,n]
     * that are coprime with n, represented as a value in [1, n].
     *
     * <p>Specifically, returns {@code φ(n)} (the numerator of φ(n)/n).
     * This interpretation matters when comparing totient across different n.
     *
     * <p>Additional branches: handles n == 1 (φ = 1, ratio = 1/1),
     * prime n (φ = n-1), and composite n.
     *
     * @param n positive integer, returns 0 if n ≤ 0
     * @return φ(n)
     */
    public static int totientNumerator(int n) {
        if (n <= 0) {
            return 0;
        }

        // Special: n == 1 → only 1 is coprime with 1, so φ(1) = 1
        if (n == 1) {
            return 1;
        }

        // Fast path: n is prime iff no divisor found up to sqrt(n)
        // Primality check using bit-assisted loop (skip even with & 1)
        boolean isPrime = true;
        if ((n & 1) == 0) {
            // Even numbers ≥ 4 are not prime
            isPrime = (n == 2);
        } else {
            for (int i = 3; i * i <= n; i += 2) {
                if (n % i == 0) {
                    isPrime = false;
                    break;
                }
            }
        }

        if (isPrime) {
            // φ(prime) = prime - 1
            return n - 1;
        }

        // General case: use full Euler computation
        return getEuler(n);
    }
}
