public class integerSqrt {
    public static int integerSqrt(int n) {
        if (n < 0) {
            return -1;
        }
        if (n == 0) {
            return 0;
        }

        int bit = 1 << 30;

        while (bit > n) {
            bit = bit >>> 2;
        }

        int result = 0;

        while (bit != 0) {
            if (n >= result + bit) {
                n = n - (result + bit);
                result = (result >>> 1) + bit;
            } else {
                result = result >>> 1;
            }
            bit = bit >>> 2;
        }

        return result;
    }
}
